/* ============================================================================
 * 1.5.0 背景音乐的冒烟测试
 *
 *   1) 配置：默认开、音量夹取、曲风只认两个内置值
 *   2) 生命周期：进页面就试着起 → 手势后补起 → 跳过 / 结束必须停
 *   3) 降级：没有 WebAudio（隐私模式 / 老环境）不许抛异常，也不许锁住动画
 *   4) 接线：台词期间压混、揭幕上扬、Host 与设置页都有这几项
 *
 * 做法与 new-options.mjs 一致：最小 DOM 桩 + vm 里跑真实的 splash.js。
 *
 * 用法：node test/bgm-audio.mjs
 * ========================================================================== */
import fs from 'node:fs'
import vm from 'node:vm'
import { fileURLToPath } from 'node:url'

const BUNDLE = fileURLToPath(new URL('../lib/splash.js', import.meta.url))
const HOST = fileURLToPath(new URL('../lib/index.js', import.meta.url))
const CLIENT = fileURLToPath(new URL('../lib/client.js', import.meta.url))
const PKG = fileURLToPath(new URL('../package.json', import.meta.url))

let pass = 0
let fail = 0
function check(label, ok, extra) {
  if (ok) { pass++; console.log('  ok   ' + label) }
  else { fail++; console.log('  FAIL ' + label + (extra !== undefined ? '  → ' + extra : '')) }
}

/* ── 最小 DOM 桩 ─────────────────────────────────────────────────────────── */
function makeEl(tag) {
  const el = {
    tagName: tag,
    _cls: '',
    _text: '',
    _html: '',
    style: { setProperty() {}, removeProperty() {} },
    dataset: {},
    children: [],
    hidden: false,
    offsetWidth: 1,
    parentNode: null,
    appendChild(c) { this.children.push(c); if (c) c.parentNode = this; return c },
    insertBefore(c) { this.children.unshift(c); if (c) c.parentNode = this; return c },
    removeChild(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); return c },
    setAttribute() {},
    getAttribute() { return null },
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent() {},
    animate() { return { cancel() {}, finish() {} } },
    getTotalLength() { return 120 },
    querySelector() { return null },
    querySelectorAll() { return [] },
    focus() {},
    contains() { return false },
  }
  Object.defineProperty(el, 'className', {
    get() { return el._cls },
    set(v) { el._cls = v == null ? '' : String(v) },
  })
  Object.defineProperty(el, 'textContent', {
    get() { return el._text },
    set(v) { el._text = v == null ? '' : String(v) },
  })
  Object.defineProperty(el, 'innerHTML', {
    get() { return el._html },
    set(v) { el._html = v == null ? '' : String(v) },
  })
  el.classList = {
    add(...cs) { cs.forEach((c) => { if (!el._cls.split(' ').includes(c)) el._cls = (el._cls + ' ' + c).trim() }) },
    remove(...cs) { cs.forEach((c) => { el._cls = el._cls.split(' ').filter((x) => x && x !== c).join(' ') }) },
    toggle(c, on) {
      const has = el._cls.split(' ').includes(c)
      const want = on === undefined ? !has : !!on
      if (want && !has) el.classList.add(c)
      if (!want && has) el.classList.remove(c)
    },
    contains(c) { return el._cls.split(' ').includes(c) },
  }
  return el
}

/* 可计数的 WebAudio 桩：每次建振荡器 / 增益都记一笔，用来看"音乐到底有没有真在排期" */
function makeAudioStub(state) {
  const ctx = {
    state: state || 'running',
    currentTime: 0,
    sampleRate: 48000,
    destination: {},
    stats: { oscillators: 0, gains: 0, noise: 0, resumed: 0, compressors: 0 },
    /* 模拟浏览器策略：没有用户手势时 resume() 不会真的把上下文放行 */
    allowResume: state === 'running',
    resume() { ctx.stats.resumed++; if (ctx.allowResume) ctx.state = 'running' },
    createOscillator() {
      ctx.stats.oscillators++
      return {
        type: '', frequency: { setValueAtTime() {}, exponentialRampToValueAtTime() {} },
        detune: { setValueAtTime() {} },
        connect() {}, start() {}, stop() {},
      }
    },
    createGain() {
      ctx.stats.gains++
      return {
        gain: {
          value: 1,
          setValueAtTime() {}, exponentialRampToValueAtTime() {},
          cancelScheduledValues() {}, linearRampToValueAtTime() {},
        },
        connect() {}, disconnect() {},
      }
    },
    createBuffer(ch, len) {
      ctx.stats.noise++
      return { getChannelData: () => new Float32Array(len) }
    },
    createBufferSource() { return { buffer: null, connect() {}, start() {}, stop() {} } },
    createBiquadFilter() { return { type: '', frequency: { value: 0 }, Q: { value: 0 }, connect() {} } },
  }
  return ctx
}

/* ── 跑一次 splash.js ────────────────────────────────────────────────────── */
function run(opts) {
  const o = opts || {}
  const listeners = {}
  const root = makeEl('div')
  root._cls = 'dsu-root dsu-boot'
  /* 同一个选择器永远返回同一个节点：splash.js 要往里 appendChild */
  const fixed = {}
  const lookup = (sel) => {
    const key = String(sel)
    if (!fixed[key]) fixed[key] = makeEl('div')
    return fixed[key]
  }
  root.querySelector = lookup

  const documentStub = {
    readyState: 'complete',
    head: makeEl('head'),
    body: makeEl('body'),
    documentElement: makeEl('html'),
    getElementById: (id) => (id === 'dsh-startup-root' ? root : null),
    createElement: (t) => makeEl(t),
    createElementNS: (_ns, t) => makeEl(t),
    querySelector: lookup,
    querySelectorAll: () => [],
    addEventListener(type, fn) { (listeners[type] = listeners[type] || []).push(fn) },
    removeEventListener(type, fn) {
      const list = listeners[type] || []
      const i = list.indexOf(fn)
      if (i >= 0) list.splice(i, 1)
    },
  }

  const timers = []
  const audioCtx = o.audio === 'none' ? null : makeAudioStub(o.audio === 'suspended' ? 'suspended' : 'running')

  const windowStub = {
    __DSH_STARTUP__: Object.assign({
      enabled: true, mode: 'always', theme: 'dark', speed: 1,
      requireInteraction: true, autoPlay: 'full',
      identity: 'JOYCE MOORE', identityId: '0087', accessLevel: '3',
      voice: false, sound: true, soundVolume: 0.5,
    }, o.config || {}),
    location: { host: '127.0.0.1:3080', href: 'http://127.0.0.1:3080/' },
    addEventListener() {}, removeEventListener() {}, dispatchEvent() {},
    sessionStorage: { getItem: () => null, setItem() {} },
    localStorage: { getItem: () => '1', setItem() {} },
    fetch: () => Promise.reject(new Error('no network in test')),
    requestAnimationFrame: (fn) => { fn(); return 1 },
    cancelAnimationFrame() {},
    /* 小延时同步跑；时间线入队不自动跑：这里只关心"音乐起没起" */
    setTimeout: (fn, ms) => {
      if ((ms || 0) <= 400) { fn(); return -1 }
      timers.push(fn)
      return timers.length
    },
    clearTimeout() {},
    setInterval: (fn) => { timers.push(fn); return timers.length },
    clearInterval() {},
    CustomEvent: function (t) { this.type = t },
  }
  if (audioCtx) windowStub.AudioContext = function () { return audioCtx }
  windowStub.window = windowStub

  const sandbox = {
    window: windowStub,
    document: documentStub,
    console: { log() {}, warn() {}, error() {} },
    Promise, Object, Array, JSON, String, Number, Math, Date, Error, RegExp, isFinite, parseInt,
    setTimeout: windowStub.setTimeout,
    clearTimeout: windowStub.clearTimeout,
    setInterval: windowStub.setInterval,
    clearInterval: windowStub.clearInterval,
    requestAnimationFrame: windowStub.requestAnimationFrame,
  }
  sandbox.globalThis = sandbox
  sandbox.self = sandbox

  vm.createContext(sandbox)
  let thrown = null
  try {
    vm.runInContext(fs.readFileSync(BUNDLE, 'utf8'), sandbox, { filename: 'splash.js' })
  } catch (e) { thrown = e }

  return {
    thrown,
    api: windowStub.__DSH_STARTUP_API__,
    audioCtx,
    listeners,
    fire(type) {
      /* 真实浏览器里手势是解锁的钥匙：先放行上下文再派发事件 */
      if (audioCtx) audioCtx.allowResume = true
      const list = (listeners[type] || []).slice()
      list.forEach((fn) => fn({ type, preventDefault() {}, stopPropagation() {} }))
      return list.length
    },
  }
}

/* ═══ 1. 配置：默认值 / 夹取 / 枚举 ══════════════════════════════════════ */
console.log('\n[1] 配置')
{
  const d = run({})
  check('初始化不抛异常', d.thrown === null, d.thrown && d.thrown.message)
  check('默认开启背景音乐（C.bgm = true）', d.api && d.api.config.bgm === true, d.api && d.api.config.bgm)
  check('默认音量 0.4', d.api && d.api.config.bgmVolume === 0.4, d.api && d.api.config.bgmVolume)
  check('默认曲风 cinematic', d.api && d.api.config.bgmStyle === 'cinematic', d.api && d.api.config.bgmStyle)

  const off = run({ config: { bgm: false } })
  check('关掉时 C.bgm = false', off.api && off.api.config.bgm === false)
  const offStr = run({ config: { bgm: 'false' } })
  check('字符串 "false" 也认作关', offStr.api && offStr.api.config.bgm === false)

  const hi = run({ config: { bgmVolume: 5 } })
  check('音量上越界夹到 1', hi.api && hi.api.config.bgmVolume === 1, hi.api && hi.api.config.bgmVolume)
  const lo = run({ config: { bgmVolume: -3 } })
  check('音量下越界夹到 0', lo.api && lo.api.config.bgmVolume === 0, lo.api && lo.api.config.bgmVolume)
  const nan = run({ config: { bgmVolume: 'abc' } })
  check('非数字回落到默认 0.4', nan.api && nan.api.config.bgmVolume === 0.4, nan.api && nan.api.config.bgmVolume)

  const pulse = run({ config: { bgmStyle: 'pulse' } })
  check('曲风 pulse 被接受', pulse.api && pulse.api.config.bgmStyle === 'pulse')
  const bad = run({ config: { bgmStyle: 'noise' } })
  check('非法曲风回落到 cinematic', bad.api && bad.api.config.bgmStyle === 'cinematic', bad.api && bad.api.config.bgmStyle)
}

/* ═══ 2. 生命周期：起 / 手势补起 / 停 ════════════════════════════════════ */
console.log('\n[2] 生命周期')
{
  const live = run({})
  check('AudioContext 已 running 时进页面就起播', live.api && live.api.bgm() === true)
  check('真的排了音（建过振荡器）', live.audioCtx.stats.oscillators > 0, live.audioCtx.stats.oscillators)

  const suspended = run({ audio: 'suspended' })
  check('被浏览器挂起时先不起', suspended.api && suspended.api.bgm() === false)
  check('挂了一次性手势监听（pointerdown）', (suspended.listeners.pointerdown || []).length > 0)
  suspended.fire('pointerdown')
  check('用户第一次点击后补起播', suspended.api && suspended.api.bgm() === true)
  check('补起播时调了 resume', suspended.audioCtx.stats.resumed > 0)

  const stopped = run({})
  stopped.api.finish()
  check('结束后音乐停（api.bgm() = false）', stopped.api.bgm() === false)

  const off = run({ config: { bgm: false } })
  check('开关关闭时完全不启动', off.api && off.api.bgm() === false && off.audioCtx.stats.oscillators === 0, off.audioCtx.stats.oscillators)
}

/* ═══ 3. 没有 WebAudio 的环境 ════════════════════════════════════════════ */
console.log('\n[3] 降级：没有 WebAudio')
{
  const none = run({ audio: 'none' })
  check('不抛异常', none.thrown === null, none.thrown && none.thrown.message)
  check('api.bgm() 安全返回 false', none.api && none.api.bgm() === false)
  check('动画 API 照常暴露', none.api && typeof none.api.replay === 'function' && typeof none.api.finish === 'function')
}

/* ═══ 4. 接线：压混 / 上扬 / 退场 与 Host、设置页 ═══════════════════════ */
console.log('\n[4] 接线与配置面板')
{
  const src = fs.readFileSync(BUNDLE, 'utf8')
  check('run() 第一件事就是 bgm.start()', /function run\(\) \{\s*\n[\s\S]{0,220}?bgm\.start\(\)/.test(src))
  check('底板出来后抬到第二档', /bgm\.setTier\(2, 2\.2\)/.test(src))
  check('每句台词都压混', /bgm\.duckUntil\(spoke\)/.test(src))
  check('终幕欢迎语也压混', /bgm\.duckUntil\(welcome\)/.test(src))
  check('揭幕前上扬', /bgm\.swell\(\)/.test(src))
  check('暂停 / 跳过时收掉音乐', /bgm\.stop\(0\.7\)/.test(src))
  check('镜头后撤时淡出', /bgm\.stop\(1\.6\)/.test(src))
  check('重播前先停旧实例（不叠两层）', /if \(bgm && bgm\.stop\) bgm\.stop\(0\)/.test(src))
  check('压混用计数，重叠台词不会互相提前抬起', /duckDepth\+\+/.test(src) && /if \(duckDepth > 0/.test(src))
  check('调度器用 40ms 前瞻', /setInterval\(tick, 40\)/.test(src))
  check('共用音频模块的上下文（不另开一个）', /context: function \(force\) \{ return ac\(force\) \}/.test(src))
  check('两套曲风都写进了谱面', /cinematic: \{/.test(src) && /pulse: \{/.test(src))
  check('注释说明了不含任何音乐文件', /不打包任何音乐文件/.test(src))

  const host = fs.readFileSync(HOST, 'utf8')
  check('Host DEFAULTS 有 bgm', /bgm: true,/.test(host))
  check('Host DEFAULTS 有 bgmVolume 0.4', /bgmVolume: 0\.4,/.test(host))
  check('Host ENUMS 认两种曲风', /bgmStyle: \['cinematic', 'pulse'\]/.test(host))
  check('Host 把 bgm 当布尔字段', /BOOL_KEYS = \[[^\]]*'bgm'\]/.test(host))
  check('Host 夹取 bgmVolume', /bgmVolume: \[0, 1\]/.test(host))

  const client = fs.readFileSync(CLIENT, 'utf8')
  check('设置页有「背景音乐」分组', /'背景音乐'/.test(client))
  check('设置页有曲风下拉', /'电影感氛围（默认）'/.test(client) && /'工业脉冲'/.test(client))
  check('设置页兜底值含 bgmVolume', /bgmVolume: 0\.4/.test(client))

  const pkg = JSON.parse(fs.readFileSync(PKG, 'utf8'))
  check('版本号是 1.5.0', pkg.version === '1.5.0', pkg.version)
  check('测试脚本纳入 bgm-audio', /test\/bgm-audio\.mjs/.test(pkg.scripts.test))
}

console.log('\n============================')
console.log(`  通过 ${pass} / 失败 ${fail}`)
console.log('============================\n')
process.exit(fail === 0 ? 0 : 1)
